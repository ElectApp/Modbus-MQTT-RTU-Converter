/*
 * Created by Somsak Elect, 29-Feb-2020
*/

#include <string.h>
#include "MySerialManager.h"

/**
 * ---------------------------------------------------
 *                CONSTANTS AND MACROS
 * ---------------------------------------------------
 */

//#define FRAME_SIZE 4




#define HALF_SILENCE_MULTIPLIER 3
#define FULL_SILENCE_MULTIPLIER 7



/**
 * ---------------------------------------------------
 *                FUNCTION MACROS
 *   https://forum.arduino.cc/index.php?topic=84364.0
 * ---------------------------------------------------
 */

#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define abs(x) ((x)>0?(x):-(x))
#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
//#define round(x)     ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
#define radians(deg) ((deg)*DEG_TO_RAD)
#define degrees(rad) ((rad)*RAD_TO_DEG)
#define sq(x) ((x)*(x))

/**
 * Initialize the serial object.
 * 
 * Use default Serial port
 */
MySerialManager::MySerialManager()
    : MySerialManager(Serial)
{
}


/**
 * Initialize the serial object.
 *
 * @param serialStream the serial stream used for the serial communication.
 * 
 */
MySerialManager::MySerialManager(HardwareSerial &serialStream)
    : _serialStream(serialStream)
{
}

/**
 * Pointer to CALLBACK_RECEIVED 
 *
 * @param CALLBACK_RECEIVED the function use for handle on read bytes finish
 * 
 * Example: *data = bytes array, len = size of *data
 * 
 *    void MySerial_callbackReceived(uint8_t *data, uint16_t len){ }
 *    
 *    At Header:
 *      MySerialManager MySerial;
 *      
 *    At Setup():
 *      MySerial.setCallbackReceived(MySerial_callbackReceived);
 * 
 */
MySerialManager& MySerialManager::setCallbackReceived(CALLBACK_RECEIVED) {
    this->callbackReceived = callbackReceived;
    return *this;
}

/**
 * Pointer to CALLBACK_SEND_START 
 *
 * @param CALLBACK_SEND_START the function use for handle on bytes array start sending
 * 
 * Example: 
 * 
 *    void MySerial_callbackSendStart(){ }
 *    
 *    At Header:
 *      MySerialManager MySerial;
 *      
 *    At Setup():
 *      MySerial.setCallbackSendStart(MySerial_callbackSendStart);
 * 
 */
MySerialManager& MySerialManager::setCallbackSendStart(CALLBACK_SEND_START) {
    this->callbackSendStart = callbackSendStart;
    return *this;
}

/**
 * Pointer to CALLBACK_SEND_END 
 * Handle on bytes array was sent
 *
 * @param CALLBACK_SEND_END the function use for handle on bytes array was sent
 * 
 * Example: 
 * 
 *    void MySerial_callbackSendEnd(){ }
 *    
 *    At Header:
 *      MySerialManager MySerial;
 *      
 *    At Setup():
 *      MySerial.setCallbackSendEnd(MySerial_callbackSendEnd);
 * 
 */
MySerialManager& MySerialManager::setCallbackSendEnd(CALLBACK_SEND_END) {
    this->callbackSendEnd = callbackSendEnd;
    return *this;
}

/**
 * Begins initializing the serial stream and checking to data incomming.
 *
 * @param baudrate the serial port baudrate.
 * @param config the data format match with #define of SerialConfig
 * look at MySerialManager.h
 * 
 */
void MySerialManager::begin(unsigned long baudrate, SerialConfig config)
{
  
    // Enable serial, disable serial stream timeout, cleans the buffer
    _serialStream.begin(baudrate, config);
    _serialStream.setTimeout(0);
    _serialStream.flush();
    _serialTransmissionBufferLength = _serialStream.availableForWrite();

    // calculate half char time time from the serial's baudrate
    if (baudrate > 19200)
    {
        _halfCharTimeInMicroSecond = 250; // 0.5T
    }
    else
    {
        _halfCharTimeInMicroSecond = 5000000 / baudrate; // 0.5T
    }

    // set the last received time to 3.5T on the future to ignore
    // request currently in the middle of transmission
    _lastCommunicationTime = micros() + (_halfCharTimeInMicroSecond * FULL_SILENCE_MULTIPLIER);

    // sets the request buffer length to zero
    _requestBufferLength = 0;  

}

/**
 * Disable serial
 * 
 */
void MySerialManager::end()
{
    _serialStream.end();
}

/**
 * Set Minimium length of bytes of serial data incoming for action
 * Ex. Modbus request bytes >= 4
 * 
 */
void MySerialManager::setFrameSize(uint16_t fsize)
{
    FRAME_SIZE = fsize;
}

/**
 * Checks data incoming and send end.
 * 
 * use at loop()
 * 
 * @return status
 */
uint8_t MySerialManager::poll(){
    
    // if we are in the writing, let it end first
    if (_isResponseBufferWriting) 
    {
        return MySerialManager::writeResponse()? STATUS_SENDING : STATUS_SEND_END;
    }

    // wait for one complete request packet
    if (!MySerialManager::readRequest())
    {   
        return _requestBufferLength>0? STATUS_RECEIVING : STATUS_IDLE;
    }

    //Callback
    if(callbackReceived)
    {
        callbackReceived(_requestBuffer, _requestBufferLength);
    }
    return STATUS_RECEIVED;
    
}

/*
 * Send bytes on serial steaming
 * 
 * @param *bytes the bytes array
 * @param offset the start index of bytes array for sending
 * @param len the number of byte count from offset
 * @return
 * 
*/
bool MySerialManager::sendBytes(const uint8_t* bytes, uint16_t offset, uint16_t len){

  if(_serialStream==NULL) return false;

  //Clear
  _responseBufferLength = 0;
  //Check size
  if(len>MAX_BUFFER){ return false; }
//  //Copy to Buffer
//  for(int i=0; i<len; i++){
//    _responseBuffer[_responseBufferLength++] = bytes[i+offset];
//  }
  //Copy to Buffer
  while(len--){
    _responseBuffer[_responseBufferLength++] = *(bytes+(offset++)); //Start from offset index, Thank: https://stackoverflow.com/q/4622461
  }
  //Start Sending
  MySerialManager::writeResponse();
  return true;
  
}


/**
 * ---------------------------------------------------
 *                PRIVATE METHOD
 * ---------------------------------------------------
 */


/**
 * Reads a new request from the serial stream and fills the request buffer
 *
 * @return true if the buffer is filled with a request and is ready to
 * be processed; otherwise false.
 */
bool MySerialManager::readRequest()
{
    if(_serialStream==NULL) return false;
    /**
     * Read one data packet and report when received completely
     */
    uint16_t lenght = _serialStream.available();
    if (lenght > 0)
    {
        // if not yet started reading
        if (!_isRequestBufferReading)
        {
            // And it already took 1.5T from the last message
            if ((micros() - _lastCommunicationTime) > (_halfCharTimeInMicroSecond * HALF_SILENCE_MULTIPLIER))
            {
                // start reading and clear buffer
                _requestBufferLength = 0;
                _isRequestBufferReading = true;
            }
            else
            {
                // discard data
                _serialStream.read();
            }
        }

        // if already in reading
        if (_isRequestBufferReading)
        {
            if (_requestBufferLength == MAX_BUFFER)
            {
                // buffer is already full; stop reading
                _isRequestBufferReading = false;
            }

            // add new bytes to buffer
            lenght = min(lenght, MAX_BUFFER - _requestBufferLength);
            lenght = _serialStream.readBytes(_requestBuffer + _requestBufferLength, MAX_BUFFER - _requestBufferLength);

            // move byte pointer forward
            _requestBufferLength += lenght;
            _totalBytesReceived += lenght;
        }

        // save the time of last received byte(s)
        _lastCommunicationTime = micros();

        // wait for more data
        return false;
    }
    else
    {
        // if we are in reading but no data is available for 1.5T; this request is completed
        if (_isRequestBufferReading && ((micros() - _lastCommunicationTime) > (_halfCharTimeInMicroSecond * HALF_SILENCE_MULTIPLIER)))
        {
            // allow for new requests to be processed
            _isRequestBufferReading = false;
        }
        else
        {
            // otherwise, wait
            return false;
        }
    }

    return !_isRequestBufferReading && (_requestBufferLength >= FRAME_SIZE);
}

/**
 * Writes the output buffer to serial stream
 *
 * @return The number of bytes written
 */
uint16_t MySerialManager::writeResponse()
{
    /**
     * Validate
     */

    // check if there is a response and this is supposed to be the first write
    if (_responseBufferWriteIndex == 0 && _responseBufferLength >= FRAME_SIZE) { 
        // set status as writing
        _isResponseBufferWriting = true;
    } 

    // check if we are not in writing
    if (!_isResponseBufferWriting) { 
        // cleanup and ignore
        _responseBufferWriteIndex = 0;
        _responseBufferLength = 0;
        return 0;
    }

    /**
     * Preparing
     */

    // if this is supposed to be the first write
    if (_responseBufferWriteIndex == 0) {
        // if we still need to wait
        if ((micros() - _lastCommunicationTime) <= (_halfCharTimeInMicroSecond * HALF_SILENCE_MULTIPLIER))
        {
            // ignore
            return 0;
        }
        
        // enter transmission mode
        if(callbackSendStart){ callbackSendStart(); }
    }

    /**
     * Transmit
     */

    // send buffer
    uint16_t length = 0;
    if (_serialTransmissionBufferLength > 0) {
        uint16_t length = min(
            _serialStream.availableForWrite(), 
            _responseBufferLength - _responseBufferWriteIndex
        );

        if (length > 0) {
            length = _serialStream.write(
                _responseBuffer + _responseBufferWriteIndex, 
                length
            );
            _responseBufferWriteIndex += length;
            _totalBytesSent += length;
        } 
        
        if (_serialStream.availableForWrite() < _serialTransmissionBufferLength)
        { 
            // still waiting for write to complete
            _lastCommunicationTime = micros();
            return length;
        }

        // if buffer reports as empty; make sure it really is 
        // (`Serial` removes bytes from buffer before sending them)
        _serialStream.flush();
    } else {
        // compatibility for badly written software serials; aka AltSoftSerial
        length = _responseBufferLength - _responseBufferWriteIndex;

        if (length > 0) {
            length = _serialStream.write(_responseBuffer, length);
            _serialStream.flush();
        }

        _responseBufferWriteIndex += length;
        _totalBytesSent += length;
    }

    if (_responseBufferWriteIndex >= _responseBufferLength &&
        (micros() - _lastCommunicationTime) > (_halfCharTimeInMicroSecond * HALF_SILENCE_MULTIPLIER)) {

        // end transmission
        if (callbackSendEnd) { callbackSendEnd(); }

        // cleanup
        _isResponseBufferWriting = false;
        _responseBufferWriteIndex = 0;
        _responseBufferLength = 0;
    }

    return length;
}
