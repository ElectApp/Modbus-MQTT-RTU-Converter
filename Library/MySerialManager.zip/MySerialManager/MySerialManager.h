/*
 * Created by Somsak Elect, 29-Feb-2020
 * Modified from https://github.com/yaacov/ArduinoModbusSlave
 * 
 * Edit:
 * 1. Manual install ESP8266 core from git 
 * https://arduino-esp8266.readthedocs.io/en/latest/installing.html#using-git-version
 * due to using 'Board Manager', it not install 'HardwareSerial' in 'core/esp8266' 
 * 
 * 2. Replace 'Steam' by 'HardwareSerial' due to complier error 'Steam Class' not found 'availableForWrite()' function
 * 
 * 
*/

#ifndef MySerialManager_h
#define MySerialManager_h
#include <Arduino.h>

#define MAX_BUFFER 256 //= SERIAL_TX_BUFFER_SIZE, SERIAL_RX_BUFFER_SIZE 

#if defined(ESP8266) || defined(ESP32)
#include <functional>
#define CALLBACK_RECEIVED std::function<void(uint8_t*, uint16_t)> callbackReceived
#define CALLBACK_SEND_START std::function<void()> callbackSendStart
#define CALLBACK_SEND_END std::function<void()> callbackSendEnd
#else
#define CALLBACK_RECEIVED void (*callbackReceived)(uint8_t*, uint16_t)
#define CALLBACK_SEND_START void (*callbackSendStart)()
#define CALLBACK_SEND_END void (*callbackSendEnd)()
#endif

enum {
  STATUS_OK = 0,
  STATUS_OVERFLOW,
  STATUS_SENDING,
  STATUS_SEND_END,
  STATUS_RECEIVING,
  STATUS_RECEIVED,
  STATUS_IDLE
};
/*
 * 
// Define config for 'SerialConfig config' of 'begin(uint64_t baudRate, SerialConfig config)'
#define SERIAL_5N1 0x00
#define SERIAL_6N1 0x02
#define SERIAL_7N1 0x04   //4
#define SERIAL_8N1 0x06   //6
#define SERIAL_5N2 0x08 
#define SERIAL_6N2 0x0A
#define SERIAL_7N2 0x0C   //12
#define SERIAL_8N2 0x0E   //14
#define SERIAL_5E1 0x20
#define SERIAL_6E1 0x22
#define SERIAL_7E1 0x24   //36
#define SERIAL_8E1 0x26   //38
#define SERIAL_5E2 0x28
#define SERIAL_6E2 0x2A
#define SERIAL_7E2 0x2C   //44
#define SERIAL_8E2 0x2E   //46
#define SERIAL_5O1 0x30
#define SERIAL_6O1 0x32
#define SERIAL_7O1 0x34   //52
#define SERIAL_8O1 0x36   //54
#define SERIAL_5O2 0x38
#define SERIAL_6O2 0x3A
#define SERIAL_7O2 0x3C   //60
#define SERIAL_8O2 0x3E   //62
*/

/**
 * @class MySerialManager
 */
class MySerialManager {
public:
    //Object
    MySerialManager();
    MySerialManager(HardwareSerial &serialStream);
    //Function
    void begin(unsigned long baudRate){ begin(baudRate, SERIAL_8N1); }
    void begin(unsigned long baudRate, SerialConfig config); 
    void end();
    void setFrameSize(uint16_t fsize);
    uint8_t poll(); //Handle
    bool sendBytes(const uint8_t* bytes, uint16_t len){ return sendBytes(bytes, 0, len); }
    bool sendBytes(const uint8_t* bytes, uint16_t offset, uint16_t len);  //Return false = it is overflow.

    //Callback
    MySerialManager& setCallbackReceived(CALLBACK_RECEIVED);
    MySerialManager& setCallbackSendStart(CALLBACK_SEND_START);
    MySerialManager& setCallbackSendEnd(CALLBACK_SEND_END);
  
private:
    HardwareSerial &_serialStream;

    uint16_t FRAME_SIZE = 0; //Minimium length of bytes of serial data incoming for action
    
    int _serialTransmissionBufferLength = MAX_BUFFER;

    uint16_t _halfCharTimeInMicroSecond;
    uint64_t _lastCommunicationTime;
    
    uint8_t _requestBuffer[MAX_BUFFER];
    uint16_t _requestBufferLength = 0;
    bool _isRequestBufferReading = false;
    
    uint8_t _responseBuffer[MAX_BUFFER];
    uint16_t _responseBufferLength = 0;
    bool _isResponseBufferWriting = false;
    uint16_t _responseBufferWriteIndex = 0;
    
    uint64_t _totalBytesSent = 0;
    uint64_t _totalBytesReceived = 0;

    //Function
    bool readRequest();
    uint16_t writeResponse();

    //Callback
    CALLBACK_RECEIVED;
    CALLBACK_SEND_START;
    CALLBACK_SEND_END;

};
#endif
